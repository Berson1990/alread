<?php $__env->startSection('page-style-level'); ?>
    <style>
        .dir {
            direction: rtl;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="about">

        <div class="panel panel-head">عن التطبيق والشروط والاحكام</div>


        <div class="row">
            <label> عن التطبيق </label>
            <el-input
                    type="textarea"
                    :rows="4"
                    placeholder="عن التطبيق  "
                    v-model="aboutPolicy.about">
            </el-input>
            <br>
            <br>


            <label for="">الشروط والاحكام </label>
            <el-input
                    type="textarea"
                    :rows="4"
                    placeholder="الشروط والاحكام "
                    v-model="aboutPolicy.policy">
            </el-input>

            <button class="btn btn-success" @click="updateAbout()"> {{ save }}</button>
        </div>


    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script-level'); ?>
    <script src="<?php echo e(asset('AppAdmin/about.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminapp.adminapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>