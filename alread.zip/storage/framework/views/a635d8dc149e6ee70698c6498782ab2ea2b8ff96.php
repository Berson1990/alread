<?php $__env->startSection('page-style-level'); ?>
    <style>
        .dir {
            direction: rtl;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="container-fluid">
        <div class="sp-50"></div>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-success">
                    <?php   echo Session::get('teachers')?>
                    <div class="panel-heading">ادخل درس جديد</div>
                    <div class="panel-body">
                        <form class="form-horizontal" action="/action_page.php" dir="rtl">
                            <?php if(is_object($teahers) || is_array($teahers)): ?>
                            <?php $__currentLoopData = $teahers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teaher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="grade_id" value="<?php echo e($teaher['grade_id']); ?>">
                            <input type="hidden" name="teacher_id" value="<?php echo e($teaher['teacher_id']); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="email">Email:</label>
                                <div class="col-sm-10">
                                    <input type="email" class="form-control" id="email" placeholder="Enter email">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="pwd">Password:</label>
                                <div class="col-sm-10">
                                    <input type="password" class="form-control" id="pwd" placeholder="Enter password">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-offset-2 col-sm-10">
                                    <div class="checkbox">
                                        <label><input type="checkbox"> Remember me</label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-offset-2 col-sm-10">
                                    <button type="submit" class="btn btn-default">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="sp-50"></div>
            <div class="row">
                <table id="teacherTable" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>Name</th>
                        <th>Position</th>
                        <th>Office</th>
                        <th>Age</th>
                        <th>Start date</th>
                        <th>Salary</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>Tiger Nixon</td>
                        <td>System Architect</td>
                        <td>Edinburgh</td>
                        <td>61</td>
                        <td>2011/04/25</td>
                        <td>$320,800</td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('page-script-level'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admintempalate.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>