<?php $__env->startSection('page-style-level'); ?>
    <style>
        .dir {
            direction: rtl;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="studentmanagment">

        <data-tables :data="studentData" :show-action-bar="false" :custom-filters="customFilters"
                     :actions-def="actionsDef">
            <el-row slot="custom-tool-bar" style="margin-bottom: 10px ; text-align: center">


                <el-col :span="5">
                    <el-input v-model="customFilters[0].vals">
                    </el-input>
                </el-col>


            </el-row>


            <el-table-column
                    prop="name"
                    label="اسم الطالب "
            >
            </el-table-column>

            <el-table-column
                    prop="phone"
                    label='الجوال '
            >
            </el-table-column>

            <el-table-column
                    prop="mail"
                    label="البريد الالكترونى"
            >
            </el-table-column>

            <el-table-column label="حظر \ فك الحظر عن الطالب">
                <template slot-scope="scope">

                    <el-button
                            v-if="scope.row.state === 0"
                            class="el-icon-edit"
                            size="medium"
                            type="danger"
                            @click="update(scope.$index, scope.row,1)">محظور
                    </el-button>
                    <el-button
                            v-if="scope.row.state === 1"
                            class="el-icon-edit"
                            size="medium"
                            type="success"
                            @click="update(scope.$index, scope.row,0)">مفعل
                    </el-button>
                </template>
            </el-table-column>



        </data-tables>


    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script-level'); ?>
    <script src="<?php echo e(asset('AppAdmin/studentmangmnet.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminapp.adminapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>