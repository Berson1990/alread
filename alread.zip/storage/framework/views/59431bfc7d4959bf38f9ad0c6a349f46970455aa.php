<?php $__env->startSection('page-style-level'); ?>
    <style>
        .dir {
            direction: rtl;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="report">
        <div class="row">

            <br>
            <data-tables :data="ReportData" :show-action-bar="false" :custom-filters="customFilters"
                         :actions-def="actionsDef">
                <el-row slot="custom-tool-bar" style="margin-bottom: 10px ; text-align: center">
                    <el-col :span="5">
                        <el-input v-model="customFilters[0].vals">
                        </el-input>
                    </el-col>

                    
                    
                    
                    
                </el-row>


                <el-table-column
                        prop="TeacherName"
                        label="اسم المدرس">
                </el-table-column>
                <el-table-column
                        prop="StuedntName"
                        label="اسم الطلب">
                </el-table-column>
                <el-table-column
                        prop="question"
                        label=" السؤال المقدم عليه الشكوى">
                </el-table-column>
                <el-table-column
                        prop="report"
                        label="   الشكوى">
                </el-table-column>


            </data-tables>


        </div>

        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('page-script-level'); ?>
            <script src="<?php echo e(asset('AppAdmin/reportquestion.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminapp.adminapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>