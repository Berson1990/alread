<?php return array (
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'barryvdh/laravel-cors' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\Cors\\ServiceProvider',
    ),
  ),
  'dawson/youtube' => 
  array (
    'providers' => 
    array (
      0 => 'Dawson\\Youtube\\YoutubeServiceProvider',
    ),
    'aliases' => 
    array (
      'Youtube' => 'Dawson\\Youtube\\Facades\\Youtube',
    ),
  ),
);